#pragma once

//Classe de base de laquelle TOUS les objets de votre moteur d�rive.
namespace LE
{
	class IBaseObject
	{};
}