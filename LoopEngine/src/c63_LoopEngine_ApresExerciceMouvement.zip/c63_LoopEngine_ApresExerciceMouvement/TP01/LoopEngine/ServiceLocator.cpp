#include "ServiceLocator.h"

ServiceLocator service_locator;